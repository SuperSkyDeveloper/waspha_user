export const folderList = {
  STORES: 'stores',
  DRIVER: 'driver',
  PRODUCTS: 'products',
  USER: 'user',
};
